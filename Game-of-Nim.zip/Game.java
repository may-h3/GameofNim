/**
 * Project 2.5.11
 *
 * Game Class for the Game of Nim 
*/
import java.util.Scanner;

public class Game
{
  //attributes 
  private Player player1;
  private Player player2;
  private boolean replay = true;
  private static int choice;

  static Scanner in = new Scanner(System.in); //creates a scanner

  //constructors
  public Game()
  {
    player1 = new Player();
    player2 = new Player();
  }

  //accessors aka getters

  //mutators aka setters
  public void play()
  {
    int currentPlayer = (int) (Math.random() * 2) + 1; //randomly chooses a player to start
    String ans;
    boolean game = true;

    while (replay)
    {
      while (game)
      {
        if (currentPlayer == 1)
        {
          guess(player1); //calls the guess method 

          if (Board.getPieces() == 1)
          {
            System.out.println("\n\n" + player1.getName() + " won!"); //announce winner
            System.out.println(player1.getName() + "'s score: " + player1.getPoints()); //print player1's score
            System.out.println(player2.getName() + "'s score: " + player2.getPoints()); //print player2's score
            game = false;
          }
          else
          {
            currentPlayer = 2; //switch to player2's turn
          }

        } // end of if
        else if (currentPlayer == 2)
        {
          guess(player2); //calls the guess method 

          if (Board.getPieces() == 1)
          {
            System.out.println("\n\n" + player2.getName() + " won!"); //announce winner 
            System.out.println(player1.getName() + "'s score: " + player1.getPoints()); //display player1's score 
            System.out.println(player2.getName() + "'s score: " + player2.getPoints()); //display player2's score 
            game = false;
          }
          else
          {
            currentPlayer = 1; //switch to player1's turn
          }

        } 
      } //end of while loop
      
      System.out.println("Replay? Yes (y) or No (n): ");
      ans = in.next();
    
      if (ans.toLowerCase().equals("y"))
      {
        Board.populateBoard(); //resets number of pieces 
        currentPlayer = (int) (Math.random() * 2) + 1; //randomly choose a player to start
        game = true;
      }
      else if (ans.toLowerCase().equals("n"))
      {
        System.out.println("Thanks for playing, see you next time!");
        replay = false;
      }
    } //end of replay loop
  } //end of play method

  /*
  * This method prompts the indicated player for the number of pieces that they would like to take away on their turn
  *
  * PRECONDITIONS: player objects need to be instantiated, board has to be populated 
  *
  * POSTCONDITIIONS: amount of game pieces has been changed, player score has increased, 
  *
  * @param - player object
  */
  public static void guess(Player obj)
  {
    System.out.println("\n"+ obj.getName() + ": There are " + Board.getPieces() + " game pieces. How many would you like to take?"); //ask player2 how many pieces they want to take away
    choice = in.nextInt();

    while (true)
    {
      if (choice < 1 || choice > Board.getPieces()/2) //if player2 selects an invalid amount of pieces
      {
        System.out.println("Invalid choice. You must take away at least 1 piece or no more than half of the available pieces. Try again: "); //prompt player2 for a new amount of pieces to take away 
        choice = in.nextInt();
      }
      else 
      {
        break;
      }
    }

    Board.removePieces(choice);
    obj.incrPoints();
  }
}