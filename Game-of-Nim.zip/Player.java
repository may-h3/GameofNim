/**
 * Project 2.5.11
 *
 * Player Class for the Game of Nim 
*/
import java.util.Scanner;

public class Player
{

  Scanner in = new Scanner(System.in); //creates a scanner

  //attributes
  private String name;
  private int points = 0;

  //constructors
  public Player() //no argument constructor
  {
    System.out.println("Enter your name: ");
    name = in.nextLine();

    //System.out.println("Welcome to the Game of Nim, " + name);
  }

  public Player(String name) //this constructor takes a string parameter
  {
    this.name = name;

    //System.out.println("Welcome to the Game of Nim, " + name);
  }

  //accessors aka getters
  public String getName()
  {
    return name;
  }

  public int getPoints()
  {
    return points;
  }

  //mutators aka setters 
  public void incrPoints()
  {
    points++;
  }
}