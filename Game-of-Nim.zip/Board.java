/**
 * Project 2.5.11
 *
 * Board Class for the Game of Nim 
*/

public class Board
{
  //attributes
  private static int pieces;
  
  //constructors

  //accessors aka getters
  public static int getPieces()
  {
    return pieces;
  }

  //mutators aka setters
  public static void populateBoard()
  {
    pieces = (int) (Math.random() * 41) + 10;
  }
  
  public static void removePieces(int num)
  {
    pieces -= num;
  }
}